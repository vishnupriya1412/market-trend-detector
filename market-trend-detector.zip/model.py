from sklearn.linear_model import LogisticRegression
import numpy as np

def train_dummy_model():
    X_train = np.random.rand(100, 4)
    y_train = np.random.choice([0, 1], size=100)
    model = LogisticRegression()
    model.fit(X_train, y_train)
    return model

def predict_trend(model, features_df):
    prediction = model.predict(features_df)
    return "Bullish" if prediction[0] == 1 else "Bearish"
