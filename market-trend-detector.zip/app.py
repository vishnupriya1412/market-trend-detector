import streamlit as st
from data_fetcher import fetch_stock_data, fetch_economic_indicators
from analysis import calculate_financial_ratios, generate_features
from model import train_dummy_model, predict_trend
import plotly.graph_objects as go

st.title("📈 Market Trend Detector")

ticker = st.text_input("Enter Stock Ticker (e.g., AAPL)", "AAPL")

if st.button("Analyze"):
    stock_data = fetch_stock_data(ticker)
    econ_data = fetch_economic_indicators()

    stock_data = calculate_financial_ratios(stock_data)
    features = generate_features(stock_data, econ_data)

    model = train_dummy_model()
    prediction = predict_trend(model, features)

    st.subheader(f"Predicted Market Trend: {prediction}")

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=stock_data.index, y=stock_data['Close'], name='Close Price'))
    fig.add_trace(go.Scatter(x=stock_data.index, y=stock_data['Rolling_Avg'], name='30D Rolling Avg'))
    st.plotly_chart(fig)
