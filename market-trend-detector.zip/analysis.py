import pandas as pd

def calculate_financial_ratios(df):
    df['Price_Change'] = df['Close'].pct_change()
    df['Rolling_Avg'] = df['Close'].rolling(window=30).mean()
    return df

def generate_features(stock_df, econ_df):
    features = {
        'avg_price_change': stock_df['Price_Change'].mean(),
        'latest_gdp_growth': econ_df['GDP_growth'].iloc[-1],
        'latest_cpi': econ_df['CPI'].iloc[-1],
        'latest_unemployment': econ_df['Unemployment_rate'].iloc[-1]
    }
    return pd.DataFrame([features])
