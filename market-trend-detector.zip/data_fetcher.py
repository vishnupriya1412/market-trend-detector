import yfinance as yf
import pandas as pd

def fetch_stock_data(ticker, period="1y"):
    stock = yf.Ticker(ticker)
    hist = stock.history(period=period)
    return hist

def fetch_economic_indicators():
    data = {
        'GDP_growth': [2.5, 2.7, 2.6, 2.9],
        'CPI': [2.1, 2.3, 2.2, 2.5],
        'Unemployment_rate': [3.5, 3.6, 3.4, 3.7]
    }
    return pd.DataFrame(data)
